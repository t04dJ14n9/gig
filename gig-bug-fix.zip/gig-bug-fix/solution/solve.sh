#!/usr/bin/env bash
set -euo pipefail

# solve.sh — Reference solution for gig_bug_fix
# Applies the compiler fix from commit 712f312

cd /workspace/gig

# Apply the compiler fix patch (fixes compileDefer and compileGo)
# The patch file is co-located with this script in solution/
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
git apply "${SCRIPT_DIR}/gig_fix.patch"

echo "Fix applied. Running smoke test..."

# Quick smoke test
go test ./tests/ -run 'TestDeferInGoroutine$' -count=1 -timeout 30s

echo "Smoke test passed."
