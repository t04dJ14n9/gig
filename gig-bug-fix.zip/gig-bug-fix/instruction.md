GIG is a Go interpreter written in Go. There is a bug in the source code that causes the interpreter to produce different results from native Go execution for certain programs involving `defer` with external method calls (e.g., `defer mu.Unlock()`).

Running `go test ./...` will reveal failing tests that demonstrate the bug. Your task is to locate and fix the bug in the compiler or VM code. Do not modify any test files. The full test suite (`go test ./...`) must pass with zero failures after your fix.
