#!/usr/bin/env bash
set -euo pipefail

# test.sh — Harbor verifier for gig_bug_fix
# Checks:
#   1. Full test suite passes (go test ./...)
#   2. gentool regeneration produces identical stdlib packages

cd /workspace/gig

PASS=true

echo "=== Check 1: Full test suite ==="
if timeout 300 go test ./... -count=1 -timeout 240s 2>&1; then
    echo "OK: full test suite passed"
else
    echo "FAIL: test suite had failures"
    PASS=false
fi

echo ""
echo "=== Check 2: gentool regeneration consistency ==="

# cmd/gig has a replace directive pointing to local source (set up in Dockerfile)
# Build the gig tool from the current (potentially fixed) source
if (cd /workspace/gig/cmd/gig && go build -o /tmp/gig-bin .) 2>&1; then
    # Snapshot current stdlib packages
    BEFORE=$(find /workspace/gig/stdlib/packages -name '*.go' -exec md5sum {} \; | sort | md5sum | awk '{print $1}')

    # Regenerate
    /tmp/gig-bin gen /workspace/gig/stdlib 2>&1 || true

    # Compare
    AFTER=$(find /workspace/gig/stdlib/packages -name '*.go' -exec md5sum {} \; | sort | md5sum | awk '{print $1}')

    if [ "$BEFORE" != "$AFTER" ]; then
        echo "FAIL: gentool regeneration produced different output"
        PASS=false
    else
        echo "OK: gentool regeneration is consistent"
    fi
else
    echo "FAIL: could not build cmd/gig"
    PASS=false
fi

# Write reward
mkdir -p /logs/verifier
if $PASS; then
    echo 1 > /logs/verifier/reward.txt
    echo "=== ALL CHECKS PASSED ==="
else
    echo 0 > /logs/verifier/reward.txt
    echo "=== SOME CHECKS FAILED ==="
fi
